<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>Golden Hives</title>

    <link href="assets/img/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/img/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/img/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/img/favicon/manifest.json" rel="manifest">
    <link href="assets/img/favicon/favicon.ico" rel="shortcut icon">

    <style>
        .site__wrapper {
            opacity: 0;
            -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
            filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        }
    </style>
    <link rel="stylesheet" href="assets/css/simple-lightbox.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body class="preload">

<div class="preload__wrap"></div>

<div class="site__wrapper">

    <header class="header__wrap scp_right">
        <div class="hm-top-strip">
            <div class="container">
                <div class="top-strip-inner">
                    <ul class="top-strip-links">
                        <li> <a href="tel:+92515266924"> <i class="icon-phone-rotary"></i> +92 (51) 526 6924</a></li>
                    </ul><!--/.top-strip-links-->

                    <ul class="top-social-links">
                        <li><a href="https://www.facebook.com" target="_blank"><i class="icon-facebook-f"></i></a>
                        </li>
                        <li><a href="https://www.twitter.com" target="_blank"><i class="icon-twitter"></i></a>
                        </li>
                        <li><a href="https://www.youtube.com" target="_blank"><i class="icon-youtube"></i></a>
                        </li>
                    </ul><!--/.top-social-links-->

                </div><!--/.top-strip-inner-->
            </div><!--/.container-->
        </div><!--/.hm-top-strip-->
        <div class="hm-navbar">
            <div class="container">

                <nav class="navbar navbar-expand-lg">

                    <a class="navbar-brand" href="#">
                        <img src="./assets/img/brand-icon.svg" alt="">
<!--                        <img src="assets/img/logo.svg" alt="">-->
                    </a><!--/.navbar-brand-->

                    <button class="navbar-toggler" data-toggle="collapse" data-target="#mainNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button><!--/.navbar-toggler-->

                    <div class="collapse navbar-collapse" id="mainNav">
                        <ul class="navbar-nav ml-auto">

                            <li class="nav-item active">
                                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                            </li>

                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    About
                                </a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">About Us</a>
                                    <a class="dropdown-item" href="#">Meet the Team</a>
                                    <a class="dropdown-item" href="#"></a>
                                </div>
                            </li>

                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Services
                                </a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>

                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Locations
                                </a>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="#">Blog</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="#">Contact Us</a>
                            </li>
                        </ul><!--/.navbar-nav-->

                    </div><!--/.collapse-->

                    <div class="outside_collapse">
                        <a href="#" class="search_link"><i class="icon-search"></i></a>
                        <a href="#" class="btn btn-lg-white">Order <span class="hide_mobile">Your Honey</span> <span class="hide_desktop">Now</span></a>
                    </div><!--/.outside_collapse-->

                </nav><!--/.navbar-->

            </div><!--/.container-->
        </div><!--/.hm-navbar-->

    </header><!--/.header__wrap-->

