<footer class="footer__wrap" style="background-image: url('./assets/img/bg.jpg')">
    <div class="foot-social-strip">
        <div class="container">
            <div class="social-strip-inner">
                <div class="brand-logo">
                    <img src="./assets/img/brand-logo.png" alt="">
                </div><!--/.brand-logo-->


                <div class="footer-social">
                    <ul>
                        <li><a href="#" class="icon-facebook-f"></a></li>
                        <li><a href="#" class="icon-twitter"></a></li>
                        <li><a href="#" class="icon-youtube"></a></li>
                    </ul>
                </div>
            </div><!--/.footer-inner-->
        </div>
    </div>
    <div class="footer-cols sec-space">
        <div class="container">
            <div class="footer-cols-inner">
                <div class="row">
                    <div class="col-md-4">
                        <div class="foot-col">
                            <p>World of Golden Hives</p>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Corporate Files</a></li>
                                <li><a href="#">Media</a></li>
                                <li><a href="#">CSR & Sustainability</a></li>
                                <li><a href="#">Corporate Stories</a></li>
                                <li><a href="#">Partners & Affiliates</a></li>
                                <li><a href="#">Events & Trade Shows</a></li>
                                <li><a href="#">Career</a></li>
                            </ul>
                        </div>
                    </div>
                     <div class="col-md-4">
                        <div class="foot-col">
                            <p>Custormer Service</p>
                            <ul>
                                <li><a href="#">About Us</a></li>
                                <li><a href="#">Corporate Files</a></li>
                                <li><a href="#">Media</a></li>
                                <li><a href="#">CSR & Sustainability</a></li>
                                <li><a href="#">Corporate Stories</a></li>
                                <li><a href="#">Partners & Affiliates</a></li>
                                <li><a href="#">Events & Trade Shows</a></li>
                                <li><a href="#">Career</a></li>
                            </ul>
                        </div>
                    </div>
                     <div class="col-md-4">
                        <div class="foot-col">
                            <p>Contact Us</p>
                            <ul>
                                <li><a href="#">Lorem ipsum dolor sit amet, dolor ipsum adipisicing.</a></li>
                                <li> <a href="tel:+92515266924"> +92 (51) 526 6924</a></li>
                                <li><a href="#">info@goldenhives.com</a></li>
                            </ul>
                            <div class="golden-map">
                                <img src="./assets/img/golden-map.png" alt="">
                            </div>
                        </div>
                    </div>

                </div>
            </div><!--/.footer-cols-inner-->
        </div>
    </div><!--/.footer-cols-->
    <div class="footer-btm-strip">

    </div>
</footer><!--/.footer__wrap-->

</div><!--/.site__wrapper-->

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/theme.js"></script>
</body>
</html>
