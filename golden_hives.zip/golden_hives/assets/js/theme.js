/**
 * @var $ jQuery
 */

// Browser ScrollBar Width function...
function getScrollBarWidth() {
    let $outer = $('<div>').css({
            visibility: 'hidden',
            width: 100,
            overflow: 'scroll'
        }).appendTo('body'),
        widthWithScroll = $('<div>').css({
            width: '100%'
        }).appendTo($outer).width();
    $outer.remove();
    return 100 - widthWithScroll;
}

let scBarWidth = getScrollBarWidth();

// Header padding equal scrollbar...
function scrollBarPadding() {
    $('.scp_right').css('padding-right', scBarWidth);
}

// Write your code here
function headerScroll() {
    let scroll = $(window).scrollTop();
    let elHeader = $('.header__wrap');
    if (scroll >= 150) {
        elHeader.addClass("affix_header");
    } else {
        elHeader.removeClass("affix_header");
    }
}

/* Window Load ---------------------- */

$(window).on('load', function () {

    setTimeout(function () {
        $('body').toggleClass('preload loaded');
    }, 500);

});


/* Document Ready ---------------------- */

$(document).ready(function () {
    scrollBarPadding();

    // Menu Toggler...
    $('.navbar-toggler').on('click', function () {
        $(this).toggleClass('open');
    });

    // BG from img src...
    $(".carousel-fs .carousel-inner .carousel-item").each(function () {
        const imgSrc = $(this).find('img').attr('src');
        $(this).css("background-image", "url('" + imgSrc + "')");
    });

    // Inline background image...
    $("[data-bg]").each(function () {
        const image = $(this).attr("data-bg");
        $(this).css({
            backgroundImage: 'url("' + image + '")',
        });
    });
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
});


/* Window Scroll ---------------------- */

$(window).on('scroll', function () {

    headerScroll();

});


/* Window Resize ---------------------- */

$(window).on('resize', function () {

    headerScroll();

});
let component = document.querySelector('ul');
component.addEventListener('click',()=>{
    component.classList.toggle('active');
})