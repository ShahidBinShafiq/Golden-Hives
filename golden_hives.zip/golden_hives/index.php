<?php include 'incl/header.php'; ?>

<div class="hero__wrapper home_hero" role="banner">
    <div id="carouselExampleControls" class="carousel slide" data-interval="false" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active" data-bg="assets/img/slider-one.jpg">
            </div>
            <div class="carousel-item" data-bg="assets/img/slider-two.jpg">
            </div>
            <div class="carousel-item" data-bg="assets/img/slider-three.jpg">
            </div>
            <div class="carousel-item" data-bg="assets/img/slider-four.jpg">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div><!--/.hero__wrapper-->

<main class="page__wrap">
    <div class="our-products sec-space">
        <div class="container">
            <div class="products-inner">
                <div class="sec-title">
                    <h4>Our Products</h4>
                </div>
                <!--                <nav>-->
                <!--                    <div class="nav nav-tabs" id="nav-tab" role="tablist">-->
                <!--                        <a class="nav-link active" id="nav-deal-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home"-->
                <!--                           aria-selected="true">Deals</a>-->
                <!--                        <a class="nav-link" id="nav-feature-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile"-->
                <!--                           aria-selected="false">Features</a>-->
                <!--                        <a class="nav-link" id="nav-wholesale-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact"-->
                <!--                           aria-selected="false">Wholesale</a>-->
                <!--                        <a class="nav-link" id="nav-flashdeal-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact"-->
                <!--                           aria-selected="false">Flash Deals</a>-->
                <!--                    </div>-->
                <!--                </nav>-->
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-deal-tab">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card sec-space-top product-col">
                                    <img src="assets/img/card-img-1.jpeg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">White Honey 950g</p>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-half checked"></span>


                                        <span>(7)</span>
                                        <div class="pricing">
                                            <p>Rs. 2800/- <small>3200</small></p>
                                        </div>
                                        <div class="discount-btn">
                                            <span class="btn-sm-golden">Discount 15%</span>
                                        </div>
                                        <div class="cart-icon">
                                            <a href="#" class="icon-cart-plus">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card sec-space-top product-col">
                                    <img src="assets/img/card-img-2.jpeg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">White Honey 950g</p>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-half checked"></span>

                                        <span>(7)</span>
                                        <div class="pricing">
                                            <p>Rs. 2800/- <small>3200</small></p>
                                        </div>
                                        <div class="discount-btn">

                                        </div>
                                        <div class="cart-icon">
                                            <a href="#" class="icon-cart-plus"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card sec-space-top product-col">
                                    <img src="assets/img/card-img-3.jpeg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">White Honey 950g</p>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-half checked"></span>

                                        <span>(7)</span>
                                        <div class="pricing">
                                            <p>Rs. 2800/- <small>3200</small></p>
                                        </div>
                                        <div class="discount-btn">
                                            <span class="btn-sm-golden">Discount 15%</span>
                                        </div>
                                        <div class="cart-icon">
                                            <a href="#" class="icon-cart-plus"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card sec-space-top product-col">
                                    <img src="assets/img/card-img-4.jpeg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">White Honey 950g</p>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-half checked"></span>

                                        <span>(7)</span>
                                        <div class="pricing">
                                            <p>Rs. 2800/- <small>3200</small></p>
                                        </div>
                                        <div class="discount-btn">

                                        </div>
                                        <div class="cart-icon">
                                            <a href="#" class="icon-cart-plus"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card sec-space-top product-col">
                                    <img src="assets/img/card-img-5.jpeg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">White Honey 950g</p>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-half checked"></span>

                                        <span>(7)</span>
                                        <div class="pricing">
                                            <p>Rs. 2800/- <small>3200</small></p>
                                        </div>
                                        <div class="discount-btn">

                                        </div>
                                        <div class="cart-icon">
                                            <a href="#" class="icon-cart-plus"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card sec-space-top product-col">
                                    <img src="assets/img/card-img-6.jpeg" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <p class="card-text">White Honey 950g</p>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-full checked"></span>
                                        <span class="icon-star-half checked"></span>

                                        <span>(7)</span>
                                        <div class="pricing">
                                            <p>Rs. 2800/- <small>3200</small></p>
                                        </div>
                                        <div class="discount-btn">
                                            <span class="btn-sm-golden">Discount 15%</span>
                                        </div>
                                        <div class="cart-icon">
                                            <a href="#" class="icon-cart-plus"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <!--                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-feature-tab">...</div>-->
                    <!--                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-wholesale-tab">...</div>-->
                    <!--                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-flashdeal-tab">...</div>-->
                </div>


            </div><!--/.products-inner-->
        </div><!--/.container-->
    </div><!--/.our-products-->



    <div class="image-gallery sec-space-top">
        <div class="sec-title">
            <h4><small>Our Honey</small>Find The Best</h4>
        </div>
        <div class="gallery">
            <ul>

                <li style="background-image: url('assets/img/gall-2.jpg')"></li>
                <li style="background-image: url('assets/img/gall-1.jpg')"></li>
<!--                <li>-->
<!---->
<!--                    <video autoplay loop muted>-->
<!--                        <source src="bg-vid.mp4" type="video/mp4">-->
<!--                    </video>-->
<!--                </li>-->
                <li style="background-image: url('assets/img/gall-3.jpg')"></li>
                <li style="background-image: url('assets/img/gall-4.jpg')"></li>

            </ul>
        </div>
    </div><!--/.image-gallery-->

    <div class="quality-section sec-space">
        <div class="container">
            <div class="quality-section-inner">
                <div class="row">
                    <div class="col-md-4">
                        <div class="quality-content">

                            <div class="card">
                                <i class="icon-dolly-flatbed"></i>
                                <div class="card-body">
                                    <h4 class="card-title">Worldwide Delivery</h4>
                                    <p class="card-text">Worlwide Diviliry Within 4 Working Days</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="quality-content">

                            <div class="card">
                                <i class="icon-clone"></i>
                                <div class="card-body">
                                    <h4 class="card-title">Return Guarantee</h4>
                                    <p class="card-text">You Have 3-days Return Guarantee For Every Single Order </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="quality-content">

                            <div class="card">
                                <i class="icon-thumbs-up"></i>
                                <div class="card-body">
                                    <h4 class="card-title">Secure Payment</h4>
                                    <p class="card-text">With Our Secure Payment Gateway Provided by Amazon. Don't Worry About Your
                                        Information</p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div><!--/.quality-section-inner-->
        </div><!--/.container-->
    </div><!--/.quality-section-->
    <div class="blog-section sec-space">
        <div class="container">
            <div class="blog-inner">
                <div class="sec-title">
                    <h4><small>Latest Blog</small>Golden Hive Knowledge Base</h4>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <picture>
                                <img src="assets/img/card-img1.jpg" class="card-img-top" alt="...">
                                <span>
                                       <a href="#">View Details</a>
                                   </span>
                            </picture>
                            <div class="card-body">
                                <div class="blog-item">
                                    <div class="blog-date">
                                        <h4>13<small>Oct 2020</small></h4>
                                    </div>
                                    <div class="blog-content">
                                        <p>Honey and Lifestyle</p>
                                        <h4>Lorem ipsum dolor sit amet, consectetur elit. </h4>
                                    </div>
                                </div><!--/.blog-item-->
                            </div>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <picture>
                                <img src="assets/img/card-img2.jpg" class="card-img-top" alt="...">
                                <span>
                                       <a href="#">View Details</a>
                                   </span>
                            </picture>
                            <div class="card-body">
                                <div class="blog-item">
                                    <div class="blog-date">
                                        <h4>13<small>Oct 2020</small></h4>
                                    </div>
                                    <div class="blog-content">
                                        <p>Honey and Lifestyle</p>
                                        <h4>Lorem ipsum dolor sit amet, consectetur elit. </h4>
                                    </div>
                                </div><!--/.blog-item-->
                            </div>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <picture>
                                <img src="assets/img/card-img3.jpg" class="card-img-top" alt="...">
                                <span>
                                       <a href="#">View Details</a>
                                   </span>
                            </picture>
                            <div class="card-body">
                                <div class="blog-item">
                                    <div class="blog-date">
                                        <h4>13<small>Oct 2020</small></h4>
                                    </div>
                                    <div class="blog-content">
                                        <p>Honey and Lifestyle</p>
                                        <h4>Lorem ipsum dolor sit amet, consectetur elit. </h4>
                                    </div>
                                </div><!--/.blog-item-->
                            </div>

                        </div>
                    </div>

                </div>
            </div><!--/.blog-inner-->
        </div><!--/.container-->
    </div><!--/.blog-section-->
</main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>
